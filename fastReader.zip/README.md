# mozilla-js_fastReader
Mozilla Extension for reading Web Pages fast in a fixed position and rate.
